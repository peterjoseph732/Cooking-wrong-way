using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    [SerializeField] GameObject loginPanel, registerPanel, mainPanel, verificationPanel;
    [SerializeField] InputField loginUserNameInput, loginPasswordInput, registerUserNameInput, registerPasswordInput;
    [SerializeField] Button signInBtn, loginBtn, signUpBtn, childAgeBtn, teenagerBtn, adultAgeBtn;
    [SerializeField] Text warningLoginText, warningRegisterText, warningVerifyText;
    ArrayList credentialsList;

    // Start is called before the first frame update
    void Start()
    {
        //getting all click events of the btns on scene
        loginBtn.onClick.AddListener(MakeUserLogin);
        signUpBtn.onClick.AddListener(ShowRegisterPanel);
        signInBtn.onClick.AddListener(OpenLoginPanel);
        childAgeBtn.onClick.AddListener(() =>
        {
            //this will notify the warning when child is playing
            warningVerifyText.text = "NOTE: PARENT/GUARDIAN SHOULD BE PRESET.";
            Invoke(nameof(ClearWarningData), 3f);
        });
        teenagerBtn.onClick.AddListener(ShowCookingAnim);
        adultAgeBtn.onClick.AddListener(ShowCookingAnim);
       
        //this condition will check if the user is already logged in the app
        if (File.Exists(Application.dataPath + "/Credentials.txt"))
        {
            credentialsList = new ArrayList(File.ReadAllLines(Application.dataPath + "/credentials.txt"));
        }
        else
            File.WriteAllText(Application.dataPath + "/Credentials.txt", "");
    }

    //this will start cooking animation after verification done
    void ShowCookingAnim()
    {
        verificationPanel.SetActive(false);
        mainPanel.GetComponent<Animator>().enabled = true;
    }

    //this will open the login panel after user registered
    void OpenLoginPanel()
    {
        loginPanel.SetActive(true);
        registerPanel.SetActive(false);
        RegisterUser();
    }

    //this method will make user to login
    void MakeUserLogin()
    {
        bool isExists = false;
        credentialsList = new ArrayList(File.ReadAllLines(Application.dataPath + "/Credentials.txt"));
        foreach (var i in credentialsList)
        {
            string detail = i.ToString();
            if (i.ToString().Substring(0, i.ToString().IndexOf(":")).Equals(loginUserNameInput.text)
                && i.ToString().Substring(i.ToString().IndexOf(":") + 1).Equals(loginPasswordInput.text))
            {
                isExists = true;
                break;
            }
        }

        if (isExists)
        {
            ShowVerificationPanel();
        }
        else
        {
            warningLoginText.text = "NO ACCOUNT FOUND, TRY SIGN UP";
            loginUserNameInput.text = "";
            loginPasswordInput.text = "";
            Invoke(nameof(ClearWarningData), 2f);
        }
    }

    //this will clear all the warning text on the panel
    void ClearWarningData()
    {
        warningLoginText.text = "";
        warningRegisterText.text = "";
        warningVerifyText.text = "";
    }

    //this will show sign up panel for user to register 
    void ShowRegisterPanel()
    {
        registerPanel.SetActive(true);
        loginPanel.SetActive(false);
    }

    //this will show the verification and btns on that check from which age category the user are from
    void ShowVerificationPanel()
    {
        loginPanel.SetActive(false);
        verificationPanel.SetActive(true);
    }


    //this method will register user and allow to login in
    void RegisterUser()
    {
        bool isExists = false;
        credentialsList = new ArrayList(File.ReadAllLines(Application.dataPath + "/Credentials.txt"));
        foreach (var i in credentialsList)
        {
            if (i.ToString().Contains(registerUserNameInput.text))
            {
                isExists = true;
                break;
            }
        }

        if (isExists)
        {
            warningRegisterText.text = "ACCOUNT ALREADY EXISTS";
        }
        else
        {
            credentialsList.Add(registerUserNameInput.text + ":" + registerPasswordInput.text);
            File.WriteAllLines(Application.dataPath + "/Credentials.txt", (String[])credentialsList.ToArray(typeof(string)));
            Debug.Log("Acoount Registered");
        }
        Invoke(nameof(ClearWarningData), 2f);
        registerUserNameInput.text = "";
        registerPasswordInput.text = "";
    }


}
