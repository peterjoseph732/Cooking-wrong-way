using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Registration : MonoBehaviour
{
    [SerializeField] GameObject loginPanel;
    [SerializeField] InputField userNameInput, passwordInput;
    [SerializeField] Button registerBtn, gotoLoginBtn;
    ArrayList credentialsList;

    // Start is called before the first frame update
    void Start()
    {
        gotoLoginBtn.onClick.AddListener(ShowLoginPanel);

        if (File.Exists(Application.dataPath + "/credentials.txt"))
        {
            credentialsList =new ArrayList(File.ReadAllLines(Application.dataPath + "/credentials.txt"));
        }
        else
            File.WriteAllText(Application.dataPath + "/credentials.txt", "");
    }

    void ShowLoginPanel()
    {
        //AddDetailsToFile();
        loginPanel.SetActive(true);
    }

    
}
